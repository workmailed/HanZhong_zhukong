#ifndef __READ_H
#define __READ_H	

void data_Parameterreceive(void);

extern u8 send_ok,receive_ok;

#endif
